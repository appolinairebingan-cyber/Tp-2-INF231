#include <stdio.h>
#include <stdlib.h>

typedef struct node {
    int data;
    struct node *p_next;
    struct node *p_prev;
} Node;

typedef struct {
    Node *p_head;
    Node *p_tail;
    int length;
} Dlist;

/* cr茅ation */
Dlist *dlist_create(void) {
    Dlist *lst = (Dlist *)malloc(sizeof(Dlist));
    if (lst == NULL) return NULL;
    lst->p_head = NULL;
    lst->p_tail = NULL;
    lst->length = 0;
    return lst;
}

/* append (queue) - liste circulaire */
Dlist *dlist_append(Dlist *p_list, int data) {
    if (p_list == NULL) return NULL;

    Node *p_new = (Node *)malloc(sizeof(Node));
    if (p_new == NULL) return p_list;

    p_new->data = data;

    if (p_list->p_tail == NULL) {  
        p_new->p_next = p_new;  
        p_new->p_prev = p_new;  
        p_list->p_head = p_new;  
        p_list->p_tail = p_new;  
    } else {  
        p_new->p_prev = p_list->p_tail;  
        p_new->p_next = p_list->p_head;  
        p_list->p_tail->p_next = p_new;  
        p_list->p_head->p_prev = p_new;  
        p_list->p_tail = p_new;  
    }  
    p_list->length++;  
    return p_list;
}

/* prepend (t锚te) - liste circulaire */
Dlist *dlist_prepend(Dlist *p_list, int data) {
    if (p_list == NULL) return NULL;

    Node *p_new = (Node *)malloc(sizeof(Node));
    if (p_new == NULL) return p_list;

    p_new->data = data;

    if (p_list->p_head == NULL) {  
        p_new->p_next = p_new;  
        p_new->p_prev = p_new;  
        p_list->p_head = p_new;  
        p_list->p_tail = p_new;  
    } else {  
        p_new->p_next = p_list->p_head;  
        p_new->p_prev = p_list->p_tail;  
        p_list->p_head->p_prev = p_new;  
        p_list->p_tail->p_next = p_new;  
        p_list->p_head = p_new;  
    }  
    p_list->length++;  
    return p_list;
}

/* affichage */
void dlist_print(Dlist *p_list) {
    if (p_list == NULL || p_list->p_head == NULL) {
        printf("(liste vide)\n");
        return;
    }
    Node *cur = p_list->p_head;
    int i = 0;
    do {
        printf("[%d]: %d  ", i++, cur->data);
        cur = cur->p_next;
    } while (cur != p_list->p_head);
    printf("\nlen = %d\n", p_list->length);
}

/* --- main de test --- */
int main(void) {
    Dlist *L = dlist_create();
    if (L == NULL) {
        fprintf(stderr, "茅chec allocation Dlist\n");
        return 1;
    }
    
    /*append ajoute en queue*/
   /*prepend ajoute en tete de notre liste*/
    dlist_prepend(L,10);
     dlist_append(L,28);
    dlist_append(L, 10);  
    dlist_append(L, 20);  
    dlist_prepend(L, 5);  
    dlist_prepend(L, 1);  

    printf("Contenu de la liste circulaire :\n");  
    dlist_print(L); // attendu: numero entr茅 

    return 0;
}