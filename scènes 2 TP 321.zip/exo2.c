Node* insertSorted(Node* head, int val) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = val;

    if (!head || val < head->data) {
        newNode->next = head;
        return newNode;
    }

    Node* current = head;
    while (current->next && current->next->data < val)
        current = current->next;

    newNode->next = current->next;
    current->next = newNode;
    return head;
}