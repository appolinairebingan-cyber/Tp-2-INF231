#include <stdio.h>
#include <stdlib.h>

// Définition du maillon
typedef struct Node {
    int data;
    struct Node* next;
} Node;

// Fonction pour insérer un élément en tête (utile pour les tests)
Node* insertHead(Node* head, int val) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = val;
    newNode->next = head;
    return newNode;
}

// Supprimer toutes les occurrences d’un élément
Node* deleteAll(Node* head, int val) {
    Node* temp;
    while (head && head->data == val) { 
        temp = head;
        head = head->next;
        free(temp);
    }

    Node* current = head;
    while (current && current->next) {
        if (current->next->data == val) {
            temp = current->next;
            current->next = current->next->next;
            free(temp);
        } else {
            current = current->next;
        }
    }
    return head;
}

// Affichage
void printList(Node* head) {
    while (head) {
        printf("%d -> ", head->data);
        head = head->next;
    }
    printf("NULL\n");
}

// Exemple d’utilisation
int main() {
    Node* head = NULL;
    head = insertHead(head, 5);
    head = insertHead(head, 3);
    head = insertHead(head, 5);
    head = insertHead(head, 2);
    head = insertHead(head, 5);

    printf("Liste initiale : ");
    printList(head);

    int x;
    printf("Entrer l'élément à supprimer : ");
    scanf("%d", &x);

    head = deleteAll(head, x);

    printf("Liste après suppression : ");
    printList(head);

    return 0;
}