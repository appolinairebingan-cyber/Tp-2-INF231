typedef struct DNode {
    int data;
    struct DNode* prev;
    struct DNode* next;
} DNode;

DNode* insertSortedD(DNode* head, int val) {
    DNode* newNode = (DNode*)malloc(sizeof(DNode));
    newNode->data = val;
    newNode->prev = newNode->next = NULL;

    if (!head || val < head->data) {
        newNode->next = head;
        if (head) head->prev = newNode;
        return newNode;
    }

    DNode* current = head;
    while (current->next && current->next->data < val)
        current = current->next;

    newNode->next = current->next;
    if (current->next) current->next->prev = newNode;
    newNode->prev = current;
    current->next = newNode;

    return head;
}