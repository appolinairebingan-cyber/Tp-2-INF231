typedef struct CNode {
    int data;
    struct CNode* next;
} CNode;

// Insertion en tête
CNode* insertHeadC(CNode* head, int val) {
    CNode* newNode = (CNode*)malloc(sizeof(CNode));
    newNode->data = val;
    if (!head) {
        newNode->next = newNode;
        return newNode;
    }
    CNode* temp = head;
    while (temp->next != head) temp = temp->next;
    temp->next = newNode;
    newNode->next = head;
    return newNode;
}

// Insertion en queue
CNode* insertTailC(CNode* head, int val) {
    CNode* newNode = (CNode*)malloc(sizeof(CNode));
    newNode->data = val;
    if (!head) {
        newNode->next = newNode;
        return newNode;
    }
    CNode* temp = head;
    while (temp->next != head) temp = temp->next;
    temp->next = newNode;
    newNode->next = head;
    return head;
}